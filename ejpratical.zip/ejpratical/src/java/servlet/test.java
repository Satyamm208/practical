/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import ejb.userbeanLocal;
import entity.Customer;
import entity.Flight;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vimlesh Kumar
 */

@WebServlet(name = "test", urlPatterns = {"/test"})
public class test extends HttpServlet{
       @EJB userbeanLocal dbl;
       
       
       
//public class test extends HttpServlet {
//
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet test</title>");            
            out.println("</head>");
            out.println("<body>");
             try{
                
                ////////////customer------------
               //dbl.intcust("abc", 898989, "ggg@gmail.com");
               
             //  dbl.editcust(2,"rk", 9899878,"rk@gmail.com" );
                
            // dbl.delcust(3);
               
           
          
                 System.out.println("CUSTOMERS DETAILS......");
            
             Collection<Customer> um = dbl.getAllCustomers();
               out.println("<table border='1'>");
               out.println("<tr>");
               out.println("<th> CUSTOMER_ID</th>");
               out.println("<th>CUSTOMER_NAME</th>");
               out.println("<th>CUSTOMER_MOBILENO.</th>");
               out.println("<th>CUSTOMER_EMAIL</th>");
               
               out.println("</tr>");
               
            for(Customer u : um)
            {
                out.println("<tr>");
                out.println("<td>" +u.getCuid()+"</td>");
                out.println("<td>" +u.getName()+"</td>");
                out.println("<td>" +u.getNo()+"</td>");
                out.println("<td>" +u.getEmail()+"</td>");
                
                out.println("</tr>");
            }
           out.println("</table>");
           out.println("<br>");
           
           
               ////////////customer------------
              // dbl.intfli("abc");
               
              dbl.editfli(2,"xyz" );
                
             dbl.delfli(3);
               
           
          
                 System.out.println("Flight DETAILS......");
            
             Collection<Flight> fg = dbl.getAllFlights();
               out.println("<table border='1'>");
               out.println("<tr>");
               out.println("<th> COMPANY_ID</th>");
               out.println("<th>COMPANY_NAME</th>");
           
               
               out.println("</tr>");
               
            for(Flight u : fg)
            {
                out.println("<tr>");
                out.println("<td>" +u.getCid()+"</td>");
                out.println("<td>" +u.getCname()+"</td>");
               
                out.println("</tr>");
            }
           out.println("</table>");
           out.println("<br>");
           
           
           
           
           
           
           
//            //------------------------------------------------------//
//            
//            
//             Collection<AdminConfirm> ac = dbl.getAllAdminConfirm();
//               out.println("<table border='1'>");
//               out.println("<tr>");
//               out.println("<th>sid</th>");
//               out.println("<th>Username</th>");
//               out.println("<th>Status</th>");
//               out.println("<th>PaymentStatus</th>");
//               out.println("</tr>");
//               
//            for(AdminConfirm u : ac)
//            {
//                out.println("<tr>");
//                out.println("<td>" +u.getSid()+"</td>");
//                out.println("<td>" +u.getUsername()+"</td>");
//                out.println("<td>" +u.getStatus()+"</td>");
//                out.println("<td>" +u.getPaymentStatus()+"</td>");
//                out.println("</tr>");
//            }
//           out.println("</table>");
//           out.println("<br>");
//            
 ////////////===========================================           
            }catch(Exception e)
            {
                System.out.println("error is"+e);
            }
            
            //out.println("<h1>Servlet test at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

      

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
