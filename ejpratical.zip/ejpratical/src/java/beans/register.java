/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import ejb.userbeanLocal;
import java.util.Collection;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author Vimlesh Kumar
 */
@Named(value = "register")
@RequestScoped
public class register {
      
    String name;
    int no;
    String email;
 
     String message;
    
    @EJB userbeanLocal esl;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    

    /**
     * Creates a new instance of register
     */
    public String insert() {
        
        
       try
        {
            esl.intcust(name, no, email);
        
            return "done.xhtml";
        }
        catch(Exception ex)
       {
           System.out.println("error is:" + ex.getMessage());
           
       }
       
        return "customer.xhtml";
    }
    
   
  

}
