/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Customer;
import entity.Details;
import entity.Flight;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author Vimlesh Kumar
 */
@Local
public interface userbeanLocal {

    public void intcust(String name, int no, String email);

    public Collection<Customer> getAllCustomers();

    public void editcust(int cuid, String name, int no, String email);

    public void delcust(int custid);

    public void intfli(String cname);

    public void editfli(int cid, String cname);

    public void delfli(int cid);

    public Collection<Flight> getAllFlights();

    public void intdel(int cid, String capacity, String source, String des, String dtime, String atime);

    public void editdel(int fid, String capacity);

    public void deldel(int fid);

    public Collection<Details> getAllDetails();
    
}
