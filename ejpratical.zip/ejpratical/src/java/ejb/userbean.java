/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Customer;
import entity.Details;
import entity.Flight;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Vimlesh Kumar
 */
@Stateless
public class userbean implements userbeanLocal {
 @PersistenceContext(unitName = "ejpraticalPU")
    EntityManager em;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
 
     //for customer
    /////INSERT
 @Override
         public void intcust(String name, int no, String email)
    {
        Customer ct=new Customer();
        ct.setName(name);
        ct.setNo(no);
        ct.setEmail(email);
                em.persist(ct);
    }
 
         
   /////EDIT   
 @Override
               public void editcust( int cuid, String name, int no, String email)
    {
      Customer ct=em.find( Customer.class,cuid);
       ct.setName(name);
       ct.setNo(no);
       ct.setEmail(email);
      // hd.setHsize(hsize);
         em.merge(ct);
    }
               
        /////DELETE       
              
 @Override
        public void delcust( int custid)
    {
      Customer ct=em.find(Customer.class,custid);
         em.remove(ct);
    }

               
    
 @Override
 public Collection<Customer> getAllCustomers() {

        Collection<Customer> S = em.createNamedQuery("Customer.findAll").getResultList();
        return S;

    }

 ///for flight
 
     /////INSERT
 
 @Override
   public void intfli(String cname)
    {
        Flight fg=new Flight();
        fg.setCname(cname);
       
                em.persist(fg);
    }
 
         
   /////EDIT   
 
 @Override
    public void editfli( int cid, String cname)
    {
      Flight fg=em.find( Flight.class,cid);
       fg.setCname(cname);
         em.merge(fg);
    }
               
        /////DELETE       
              
 
 @Override
        public void delfli( int cid)
    {
      Flight fg=em.find(Flight.class,cid);
         em.remove(fg);
    }

               
    
 
 @Override
 public Collection<Flight> getAllFlights() {

        Collection<Flight> S = em.createNamedQuery("Flight.findAll").getResultList();
        return S;

    }
 
     ///for flight_details
 
     /////INSERT
 
 @Override
   public void intdel(int cid, String capacity, String source, String des, String dtime, String atime)
    {
        Details dl=new Details();
        dl.setCid(cid);
        dl.setCapacity(capacity);
       dl.setSource(source);
       dl.setDes(des);
       dl.setDtime(dtime);
       dl.setAtime(atime);
                em.persist(dl);
    }
 
         
   /////EDIT   
 
 @Override
    public void editdel( int fid, String capacity)
    {
      Details dl=em.find( Details.class,fid);
       dl.setCapacity(capacity);
         em.merge(dl);
    }
               
        /////DELETE       
              
 
 @Override
        public void deldel( int fid)
    {
      Details dl=em.find(Details.class,fid);
         em.remove(dl);
    }

               
    
 
 @Override
 public Collection<Details> getAllDetails() {

        Collection<Details> S = em.createNamedQuery("Details.findAll").getResultList();
        return S;

    }
 
         
 
     
 
}
