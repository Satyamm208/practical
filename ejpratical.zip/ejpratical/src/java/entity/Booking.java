/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Vimlesh Kumar
 */
@Entity
@Table(name = "booking")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Booking.findAll", query = "SELECT b FROM Booking b"),
    @NamedQuery(name = "Booking.findByNoofperson", query = "SELECT b FROM Booking b WHERE b.noofperson = :noofperson")})
public class Booking implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "noofperson")
    private Integer noofperson;
    @JoinColumn(name = "cuid", referencedColumnName = "cuid")
    @ManyToOne(optional = false)
    private Customer cuid;
    @JoinColumn(name = "fid", referencedColumnName = "fid")
    @ManyToOne(optional = false)
    private Details fid;

    public Booking() {
    }

    public Booking(Integer noofperson) {
        this.noofperson = noofperson;
    }

    public Integer getNoofperson() {
        return noofperson;
    }

    public void setNoofperson(Integer noofperson) {
        this.noofperson = noofperson;
    }

    public Customer getCuid() {
        return cuid;
    }

    public void setCuid(Customer cuid) {
        this.cuid = cuid;
    }

    public Details getFid() {
        return fid;
    }

    public void setFid(Details fid) {
        this.fid = fid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (noofperson != null ? noofperson.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Booking)) {
            return false;
        }
        Booking other = (Booking) object;
        if ((this.noofperson == null && other.noofperson != null) || (this.noofperson != null && !this.noofperson.equals(other.noofperson))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Booking[ noofperson=" + noofperson + " ]";
    }
    
}
