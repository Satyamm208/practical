/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package REST;



import ejb.userbeanLocal;
import java.util.Collection;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Vimlesh Kumar
 */
@Path("generic")
@DeclareRoles({"User"})
public class OnlineAddResource {
@EJB userbeanLocal pb;

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of OnlineAddResource
     */
    public OnlineAddResource() {
    }

    
      @RolesAllowed("User")
    @POST
    @Path("intcust/{name}/{no}/{email}")
    public void insert(@PathParam("name") String name,@PathParam("email") String email,@PathParam("no") int no) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       pb.intcust(name, no, email);
    }
    
    
//   
    /**
     * PUT method for updating or creating an instance of OnlineAddResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
